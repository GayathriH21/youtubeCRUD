# YouTube CRUD

A Python package to perform CRUD operations on YouTube videos.

## Installation

```bash
pip install youtube_crud
